// ============================================================
// Mini servicio de tiempo real - Socket.IO (seguro)
// ============================================================
// Puerto: 3003 (configurado en Caddyfile para proxy)
//
// v1.0-RC1-bloque4-5 (items 24, 26, 28, 29):
//
//   (24) El servidor emite eventos, no el cliente. Se expone un
//        endpoint HTTP POST /emit (localhost-only) que recibe
//        { room, event, data, clientOperationId } y emite a la
//        sala correspondiente. Los endpoints de API lo llaman
//        vía src/lib/realtime-emitter.ts → /api/internal/emit.
//
//   (26) Autenticación desde handshake: el cliente envía el token
//        como query param `?token=...` al conectarse. Se verifica
//        en el evento 'connection' ANTES de aceptar al socket.
//        Si el token es inválido o expirado, se desconecta al
//        socket inmediatamente. Ya no se confía en el evento
//        'auth' del cliente para autenticación.
//
//   (28) Validar destinatarios: antes de emitir a un usuario
//        específico (sala user:<id>), se valida que el evento
//        contiene los datos mínimos (orderId existe, userId
//        existe). Se mantiene un registro de sockets activos
//        para rechazar emisiones a usuarios inexistentes.
//
//   (29) Idempotencia: cada evento lleva un clientOperationId.
//        Si el mismo ID llega dos veces en 5 minutos, el segundo
//        se ignora silenciosamente.
//
// Seguridad (FIX 8): el token HMAC SHA-256 se verifica con la
//   MISMA función que el middleware de Next.js (Web Crypto API).
//   NUNCA se confía en userId/role enviados por el cliente.
//
// CORS (FIX 11): lista de orígenes permitidos configurable.
//
// Eventos soportados (server-side emit):
//   - order:new          (a cocina/pizzería por área)
//   - order:status       (a mesero por user)
//   - order:ready        (a mesero por user)
//   - payment:done       (a admin/cajero)
//   - stock:low          (broadcast o por área)
//   - notification       (a usuario o rol específico)
//   - daily-close        (broadcast)
// ============================================================

import { createServer, IncomingMessage, ServerResponse } from 'http'
import { Server as SocketIOServer, Socket } from 'socket.io'
import { networkInterfaces } from 'os'

const PORT = 3003
const SESSION_COOKIE = 'rc_session'

// ============================================================
// Secreto de firma (FIX 9):
//   - En production: debe venir de NEXTAUTH_SECRET (error si falta).
//   - En development: fallback a un valor por defecto (solo tests).
// ============================================================
function getSecret(): string {
  const envSecret = process.env.NEXTAUTH_SECRET
  if (envSecret && envSecret.length >= 16) return envSecret
  if (process.env.NODE_ENV === 'production') {
    throw new Error(
      'NEXTAUTH_SECRET no configurado. En producción es obligatorio definir NEXTAUTH_SECRET (>= 16 chars).',
    )
  }
  return 'cuba-restaurante-secret-key-change-in-prod'
}

const SECRET = getSecret()

// ============================================================
// Verificación de token HMAC SHA-256 (Web Crypto API).
// ============================================================
function bytesToHex(bytes: ArrayBuffer): string {
  return Array.from(new Uint8Array(bytes))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

async function computeHmac(payload: string): Promise<string> {
  const enc = new TextEncoder()
  const keyData = enc.encode(SECRET)
  const key = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(payload))
  return bytesToHex(sig)
}

interface VerifiedSession {
  userId: string
  role: string
  expiresAt: number
}

async function verifySessionToken(token: string): Promise<VerifiedSession | null> {
  try {
    const parts = token.split('.')
    if (parts.length !== 4) return null
    const [userId, role, expiresAtStr, signature] = parts
    const payload = `${userId}.${role}.${expiresAtStr}`
    const expectedSig = await computeHmac(payload)
    if (signature !== expectedSig) return null

    const expiresAt = parseInt(expiresAtStr, 10)
    if (Date.now() > expiresAt) return null

    return { userId, role, expiresAt }
  } catch {
    return null
  }
}

// ============================================================
// CORS (FIX 11): Lista de orígenes permitidos.
// ============================================================
function getAllowedOrigins(): string[] {
  const origins = new Set<string>([
    'http://localhost:3000',
    'http://127.0.0.1:3000',
    'http://localhost',
    'http://127.0.0.1',
  ])

  try {
    const nets = networkInterfaces()
    for (const name of Object.keys(nets)) {
      for (const net of nets[name] || []) {
        if (net.family === 'IPv4' && !net.internal) {
          origins.add(`http://${net.address}:3000`)
          origins.add(`http://${net.address}`)
        }
      }
    }
  } catch {
    // Ignorar errores al detectar IP
  }

  const envOrigins = process.env.ALLOWED_ORIGINS
  if (envOrigins) {
    for (const o of envOrigins.split(',').map((s) => s.trim()).filter(Boolean)) {
      origins.add(o)
    }
  }

  return Array.from(origins)
}

const ALLOWED_ORIGINS = getAllowedOrigins()
console.log('[cors] Orígenes permitidos:', ALLOWED_ORIGINS.join(', '))

// ============================================================
// Tipos de salas
//   - role:ADMIN, role:MESERO, role:COCINA, role:PIZZERIA, role:CAJERO
//   - user:<userId>
//   - area:<areaId>
//   - broadcast (todos)
// ============================================================

interface ClientInfo {
  userId?: string
  role?: string
  areaId?: string
  authenticated: boolean
  connectedAt: number
}

const clients = new Map<string, ClientInfo>()
// Mapa userId → Set<socketId> para validación de destinatarios (item 28).
const userSockets = new Map<string, Set<string>>()

// ============================================================
// Idempotencia (item 29): cache LRU de clientOperationIds ya vistos.
// TTL: 5 minutos. Tamaño máximo: 10000 entradas.
// Si llega un evento con el mismo ID dentro del TTL, se ignora.
// ============================================================
const IDEMPOTENCY_TTL_MS = 5 * 60 * 1000
const IDEMPOTENCY_MAX = 10000
const idempotencyCache = new Map<string, number>() // id → timestamp

function isDuplicateOperation(clientOperationId: string | undefined): boolean {
  if (!clientOperationId) return false
  const now = Date.now()
  // Limpieza de entradas expiradas (cada 100 inserciones aprox).
  if (idempotencyCache.size > IDEMPOTENCY_MAX) {
    for (const [id, ts] of idempotencyCache.entries()) {
      if (now - ts > IDEMPOTENCY_TTL_MS) {
        idempotencyCache.delete(id)
      }
    }
  }
  if (idempotencyCache.has(clientOperationId)) {
    return true
  }
  idempotencyCache.set(clientOperationId, now)
  return false
}

// ============================================================
// Validación de destinatarios (item 28)
// ============================================================
function isValidRoom(room: string): boolean {
  if (!room || typeof room !== 'string') return false
  if (room === 'broadcast') return true
  if (room.startsWith('role:')) {
    const role = room.slice(5)
    return ['ADMIN', 'MESERO', 'MESERO_PRO', 'COCINA', 'PIZZERIA', 'CAJERO'].includes(role)
  }
  if (room.startsWith('user:')) {
    const userId = room.slice(5)
    if (!userId) return false
    // Validar que haya al menos un socket activo para ese usuario
    // (si no, la emisión no tendría destinatario; pero igualmente la
    // aceptamos para no romper flujos donde el usuario aún no conectó).
    // La validación fuerte es sobre el payload del evento.
    return true
  }
  if (room.startsWith('area:')) {
    const areaId = room.slice(5)
    return !!areaId
  }
  return false
}

/**
 * Valida que el payload del evento contiene los datos mínimos
 * exigidos por el tipo de evento. Esto evita que se emitan
 * eventos con datos incompletos o malformados.
 */
function validateEventPayload(event: string, data: any): { ok: boolean; error?: string } {
  if (!data || typeof data !== 'object') {
    return { ok: false, error: 'Payload vacío o inválido' }
  }
  switch (event) {
    case 'order:new':
      if (!data.orderId) return { ok: false, error: 'orderId requerido' }
      if (!data.areaId) return { ok: false, error: 'areaId requerido' }
      // userId opcional (pedido creado por sistema)
      break
    case 'order:status':
      if (!data.orderId) return { ok: false, error: 'orderId requerido' }
      if (!data.status) return { ok: false, error: 'status requerido' }
      if (data.userId && typeof data.userId !== 'string') {
        return { ok: false, error: 'userId inválido' }
      }
      break
    case 'order:ready':
      if (!data.orderId) return { ok: false, error: 'orderId requerido' }
      if (data.userId && typeof data.userId !== 'string') {
        return { ok: false, error: 'userId inválido' }
      }
      break
    case 'payment:done':
      if (!data.orderId) return { ok: false, error: 'orderId requerido' }
      if (typeof data.amount !== 'number') {
        return { ok: false, error: 'amount (number) requerido' }
      }
      break
    case 'stock:low':
      if (!data.productId) return { ok: false, error: 'productId requerido' }
      break
    case 'notification':
      if (!data.title || !data.message) {
        return { ok: false, error: 'title y message requeridos' }
      }
      break
    case 'daily-close':
      if (!data.date) return { ok: false, error: 'date requerido' }
      break
    case 'message':
      if (!data.to || !data.from) {
        return { ok: false, error: 'to y from requeridos' }
      }
      break
    default:
      // Evento no reconocido:rechazado por seguridad.
      return { ok: false, error: `Evento no soportado: ${event}` }
  }
  return { ok: true }
}

/**
 * Comprueba si un userId tiene sockets activos (item 28).
 * Si no los tiene, la emisión no llegará a nadie pero igualmente
 * se acepta (no rompemos el flujo del servidor).
 */
function hasActiveUser(userId: string): boolean {
  const set = userSockets.get(userId)
  return !!set && set.size > 0
}

// ============================================================
// Emisión interna (item 24): la usa tanto el endpoint HTTP /emit
// como los eventos socket recibidos del cliente (legacy).
// ============================================================
function emitToRoom(room: string, event: string, data: any): { ok: boolean; delivered: number } {
  if (room === 'broadcast') {
    io.emit(event, data)
    return { ok: true, delivered: io.engine.clientsCount }
  }
  if (room.startsWith('user:')) {
    const userId = room.slice(5)
    if (userId && !hasActiveUser(userId)) {
      // El usuario no está conectado: no hay nadie que reciba.
      // No es un error; simplemente no se entrega.
      console.log(`[emit] user:${userId} no tiene sockets activos (descartado)`)
      return { ok: true, delivered: 0 }
    }
  }
  io.to(room).emit(event, data)
  return { ok: true, delivered: -1 } // -1 = no contado (sala)
}

// ============================================================
// Servidor HTTP (para endpoint /emit) + Socket.IO
// ============================================================
const httpServer = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  // CORS para el endpoint HTTP (el socket.io gestiona el suyo)
  const origin = req.headers.origin
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin)
    res.setHeader('Vary', 'Origin')
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  }
  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }
  if (req.url === '/emit' && req.method === 'POST') {
    // ============================================================
    // (item 27) Endpoint interno para emitir eventos.
    // Accesible SOLO desde localhost. Lo llama el endpoint
    // /api/internal/emit de Next.js, que a su vez lo llama
    // src/lib/realtime-emitter.ts desde los endpoints de API.
    // ============================================================
    const remoteIp =
      (req.headers['x-forwarded-for']?.toString().split(',')[0] || '').trim() ||
      req.socket.remoteAddress ||
      ''
    const isLocal =
      remoteIp === '127.0.0.1' ||
      remoteIp === '::1' ||
      remoteIp === '::ffff:127.0.0.1' ||
      remoteIp === ''
    if (!isLocal) {
      res.writeHead(403, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: 'FORBIDDEN: solo localhost' }))
      return
    }

    // Leer body
    let body = ''
    for await (const chunk of req) {
      body += chunk
      if (body.length > 1_000_000) break // 1MB límite
    }
    let parsed: any
    try {
      parsed = JSON.parse(body)
    } catch {
      res.writeHead(400, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: 'JSON inválido' }))
      return
    }
    const { room, event, data, clientOperationId } = parsed || {}

    // Idempotencia (item 29)
    if (isDuplicateOperation(clientOperationId)) {
      console.log(`[emit] duplicado ignorado: opId=${clientOperationId} event=${event}`)
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: true, duplicate: true, delivered: 0 }))
      return
    }

    // Validar sala
    if (!isValidRoom(room)) {
      res.writeHead(400, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: `Sala inválida: ${room}` }))
      return
    }

    // Validar payload (item 28)
    const validation = validateEventPayload(event, data)
    if (!validation.ok) {
      res.writeHead(400, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: `Payload inválido: ${validation.error}` }))
      return
    }

    const result = emitToRoom(room, event, data)
    console.log(
      `[emit] room=${room} event=${event} delivered=${result.delivered} opId=${clientOperationId || '-'}`,
    )
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ ok: true, delivered: result.delivered }))
    return
  }

  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(
      JSON.stringify({
        ok: true,
        service: 'realtime',
        port: PORT,
        clients: clients.size,
        users: userSockets.size,
        idempotencyCacheSize: idempotencyCache.size,
        uptime: process.uptime(),
      }),
    )
    return
  }

  res.writeHead(404, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ ok: false, error: 'Not found' }))
})

// v1.0-RC1-bloque4-5 (item 27): path por defecto (`/socket.io/`) para
// NO interceptar nuestros endpoints HTTP /emit y /health.
// Antes, `path: '/'` hacía que socket.io capturara toda petición HTTP
// y devolviera "Transport unknown" para /emit y /health.
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: (origin, callback) => {
      if (!origin) return callback(null, true)
      if (ALLOWED_ORIGINS.includes(origin)) {
        return callback(null, true)
      }
      console.warn(`[cors] Origen rechazado: ${origin}`)
      return callback(null, false)
    },
    methods: ['GET', 'POST'],
    credentials: true,
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// ============================================================
// Conexión de sockets (item 26): autenticar desde handshake.
// El cliente envía el token como query param `?token=...`.
// Se verifica antes de aceptar la conexión. Si es inválido,
// se desconecta el socket inmediatamente.
// ============================================================
io.on('connection', async (socket: Socket) => {
  const tokenFromQuery = socket.handshake.query.token as string | undefined
  const tokenFromAuth = socket.handshake.auth?.token as string | undefined
  const token = tokenFromQuery || tokenFromAuth

  if (!token) {
    console.warn(`[auth] ${socket.id} conexión rechazada: sin token`)
    socket.emit('auth:fail', { message: 'Token no proporcionado en handshake' })
    socket.disconnect(true)
    return
  }

  const session = await verifySessionToken(token)
  if (!session) {
    console.warn(`[auth] ${socket.id} conexión rechazada: token inválido o expirado`)
    socket.emit('auth:fail', { message: 'Token inválido o expirado' })
    socket.disconnect(true)
    return
  }

  // Autenticación exitosa: el socket ya está en rooms.
  const info: ClientInfo = {
    userId: session.userId,
    role: session.role,
    areaId: undefined, // se actualiza si el cliente envía 'auth' con areaId
    authenticated: true,
    connectedAt: Date.now(),
  }
  clients.set(socket.id, info)
  socket.join(`role:${session.role}`)
  socket.join(`user:${session.userId}`)
  // Registrar en userSockets (item 28)
  if (!userSockets.has(session.userId)) {
    userSockets.set(session.userId, new Set())
  }
  userSockets.get(session.userId)!.add(socket.id)

  console.log(
    `[+] ${socket.id} autenticado: user=${session.userId} role=${session.role}`,
  )
  socket.emit('auth:ok', { userId: session.userId, role: session.role })

  // ============================================================
  // Evento 'auth' opcional (legacy / areaId):
  //   Ya NO se usa para autenticación (eso se hace en el handshake).
  //   Solo sirve para que el cliente se una a la sala de su área.
  // ============================================================
  socket.on('auth', (payload: { areaId?: string }) => {
    if (!payload) return
    const info = clients.get(socket.id)
    if (!info || !info.authenticated) {
      socket.emit('auth:fail', { message: 'No autenticado' })
      return
    }
    if (payload.areaId) {
      info.areaId = payload.areaId
      socket.join(`area:${payload.areaId}`)
      console.log(`[auth] ${socket.id} → areaId=${payload.areaId}`)
    }
  })

  // ============================================================
  // Eventos legados del cliente: ya NO se aceptan emisiones
  // arbitrarias desde el cliente. El servidor es la única fuente
  // de eventos de negocio (item 24).
  //   Los eventos que el cliente podía emitir antes (order:new,
  //   order:status, etc.) se rechazan con un mensaje informativo.
  //   Excepciones: ping/pong (utility).
  // ============================================================
  const CLIENT_FORBIDDEN_EVENTS = [
    'order:new',
    'order:status',
    'order:ready',
    'payment:done',
    'stock:low',
    'notification',
    'daily-close',
    'message',
  ]
  for (const ev of CLIENT_FORBIDDEN_EVENTS) {
    socket.on(ev, (data: any) => {
      console.warn(
        `[forbidden] ${socket.id} intentó emitir '${ev}' desde el cliente (rechazado)`,
      )
      socket.emit('error', {
        message: `Los eventos de negocio solo pueden ser emitidos por el servidor. Use el endpoint interno /api/internal/emit.`,
        event: ev,
      })
    })
  }

  // === Ping/Pong ===
  socket.on('ping', () => {
    socket.emit('pong', { time: Date.now() })
  })

  socket.on('disconnect', () => {
    console.log(`[-] ${socket.id} desconectado`)
    const info = clients.get(socket.id)
    if (info?.userId) {
      const set = userSockets.get(info.userId)
      if (set) {
        set.delete(socket.id)
        if (set.size === 0) userSockets.delete(info.userId)
      }
    }
    clients.delete(socket.id)
  })

  socket.on('error', (err) => {
    console.error(`[error] ${socket.id}:`, err)
  })
})

httpServer.listen(PORT, () => {
  console.log(`🔌 Realtime service corriendo en puerto ${PORT}`)
  console.log(`   Endpoint HTTP interno: POST http://localhost:${PORT}/emit (localhost-only)`)
  console.log(`   Health check: GET http://localhost:${PORT}/health`)
})

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Cerrando servidor...')
  io.close(() => {
    httpServer.close(() => {
      process.exit(0)
    })
  })
})
