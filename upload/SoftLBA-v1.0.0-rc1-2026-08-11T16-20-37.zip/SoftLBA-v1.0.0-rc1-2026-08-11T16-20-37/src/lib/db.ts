import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// v1.0-RC1-bloque1-2: clear cached client when the Prisma client is regenerated
// (e.g. after db:push/db:generate adds new fields). The cached singleton retains
// the schema from when it was first instantiated; on schema changes the new
// fields cause PrismaClientValidationError unless we rebuild it.
if (globalForPrisma.prisma && process.env.NODE_ENV !== 'production') {
  try {
    // Best-effort disconnect; ignore errors.
    globalForPrisma.prisma.$disconnect().catch(() => undefined)
  } catch {}
  globalForPrisma.prisma = undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db