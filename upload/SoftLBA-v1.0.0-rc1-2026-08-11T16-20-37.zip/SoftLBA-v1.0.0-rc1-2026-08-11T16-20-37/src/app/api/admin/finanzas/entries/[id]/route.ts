// PATCH /api/admin/finanzas/entries/[id] - Actualizar entrada
// DELETE /api/admin/finanzas/entries/[id] - Anular entrada (v1.0-RC1-bloque2-3 item 23)
//
// v1.0-RC1-bloque2-3 (item 23): DELETE ya NO elimina físicamente la entrada.
// En su lugar, llama a la misma lógica de anulación que
// POST /api/admin/finanzas/entries/[id]/annul (helper `annulFinanceEntry`).
// Esto evita pérdida de trazabilidad y mantiene el balance contable
// (crea entrada compensatoria en lugar de borrar).
//
// El body de DELETE puede incluir `reason` (motivo). Si no se incluye,
// se usa un reason por defecto indicando que fue eliminado vía DELETE.
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { hasPerm, PERMISSIONS } from '@/lib/permissions/permissions-v2'
import { annulFinanceEntry, AnnulError } from '@/lib/finance-annul'
import { computeConvertedAmount } from '@/lib/currency'
import { z } from 'zod'

const PatchSchema = z.object({
  type: z.enum(['INGRESO', 'EGRESO', 'GASTO', 'SALARIO']).optional(),
  category: z.string().min(1).max(80).optional(),
  description: z.string().min(1).max(300).optional(),
  amount: z.coerce.number().refine((n) => n !== 0).optional(),
  currency: z.string().max(10).optional(),
  reference: z.string().max(200).optional().or(z.literal('')).optional(),
})

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ ok: false, error: 'NO_AUTENTICADO' }, { status: 401 })
    if (!hasPerm(user.role, PERMISSIONS.FINANCE_EDIT)) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }

    const json = await req.json().catch(() => null)
    if (!json) return NextResponse.json({ ok: false, error: 'Cuerpo inválido' }, { status: 400 })
    const parsed = PatchSchema.safeParse(json)
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: parsed.error.issues[0]?.message || 'Datos inválidos' }, { status: 400 })
    }
    const d = parsed.data

    const existing = await db.financeEntry.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })
    }

    const data: any = {}
    if (d.type !== undefined) data.type = d.type
    if (d.category !== undefined) data.category = d.category
    if (d.description !== undefined) data.description = d.description
    if (d.amount !== undefined) data.amount = Math.abs(d.amount)
    if (d.currency !== undefined) data.currency = d.currency
    if (d.reference !== undefined) data.reference = d.reference || null

    // v1.0-RC1-bloque2-3 (item 22): si cambia amount o currency, recalcular
    // convertedAmount usando la snapshot de tasa (o la actual si no había).
    if (d.amount !== undefined || d.currency !== undefined) {
      const amount = d.amount !== undefined ? Math.abs(d.amount) : existing.amount
      const currency = (d.currency || existing.currency || 'CUP').toUpperCase()
      const rate =
        existing.exchangeRate != null && existing.exchangeRate > 0
          ? existing.exchangeRate
          : (await db.restaurantConfig.findFirst({ where: { id: 'config-1' } }))?.usdToCup || 320
      data.exchangeRate = rate
      data.convertedAmount = computeConvertedAmount(amount, currency, rate)
      data.baseCurrency = 'CUP'
    }

    const updated = await db.financeEntry.update({ where: { id }, data })

    await audit({
      userId: user.id,
      action: 'UPDATE',
      entity: 'finance-entry',
      entityId: id,
      before: existing,
      after: updated,
    })

    return NextResponse.json({ ok: true, item: updated })
  } catch (e: any) {
    console.error('PATCH /api/admin/finanzas/entries/[id]', e)
    return NextResponse.json({ ok: false, error: 'Error interno' }, { status: 500 })
  }
}

const DeleteSchema = z.object({
  reason: z.string().max(500).optional(),
})

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ ok: false, error: 'NO_AUTENTICADO' }, { status: 401 })
    if (!hasPerm(user.role, PERMISSIONS.FINANCE_EDIT)) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }

    const existing = await db.financeEntry.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })
    }

    // v1.0-RC1-bloque2-3 (item 23): DELETE ahora anula en lugar de borrar.
    // Se acepta un `reason` opcional en el body; si no viene, se usa uno por
    // defecto que indique que se hizo vía DELETE.
    const body = await req.json().catch(() => ({}))
    const parsed = DeleteSchema.safeParse(body)
    const reason =
      parsed.success && parsed.data.reason && parsed.data.reason.trim().length >= 3
        ? parsed.data.reason
        : `Anulación por eliminación directa (DELETE) — usuario ${user.username || user.id}`

    const { annulled, compensation } = await annulFinanceEntry(id, user.id, reason)

    await audit({
      userId: user.id,
      action: 'FINANCE_ENTRY_ANNUL',
      entity: 'finance-entry',
      entityId: id,
      before: {
        status: existing.status,
        type: existing.type,
        amount: existing.amount,
        currency: existing.currency,
      },
      after: {
        status: annulled.status,
        annulReason: annulled.annulReason,
        annulledAt: annulled.annulledAt,
        compensationEntryId: compensation.id,
        compensationType: compensation.type,
        compensationAmount: compensation.amount,
        viaDelete: true,
      },
    })

    return NextResponse.json({
      ok: true,
      annulled,
      compensation,
      note: 'Entrada anulada (no eliminada físicamente). Vía POST /annul para el flujo estándar.',
    })
  } catch (e: any) {
    if (e instanceof AnnulError) {
      if (e.code === 'NOT_FOUND') {
        return NextResponse.json({ ok: false, error: e.message }, { status: 404 })
      }
      if (e.code === 'ALREADY_ANNULLED') {
        return NextResponse.json({ ok: false, error: e.message }, { status: 400 })
      }
    }
    console.error('DELETE /api/admin/finanzas/entries/[id]', e)
    return NextResponse.json({ ok: false, error: 'Error interno' }, { status: 500 })
  }
}
