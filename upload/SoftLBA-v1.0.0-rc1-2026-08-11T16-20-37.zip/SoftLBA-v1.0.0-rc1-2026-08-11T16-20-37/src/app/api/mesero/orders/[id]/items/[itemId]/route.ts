// PATCH /api/mesero/orders/[id]/items/[itemId] - Editar cantidad/notas de un item
//   - Para FINAL: solo si el item está PENDIENTE
//   - Para DIRECTO: si no está CANCELADO (item 16): ajusta diferencia de stock
// DELETE /api/mesero/orders/[id]/items/[itemId] - Cancelar item
//   - Para FINAL: solo si está PENDIENTE
//   - Para DIRECTO: si no está CANCELADO (item 17): devuelve stock al AreaInventory
//   - El item se marca como CANCELADO, NO se borra (trazabilidad)
//   - Recalcula totales del pedido
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { decrementDirectoStock, returnDirectoStock } from '@/lib/directo-stock'
import { recalculateOrderStatus } from '@/lib/order-state-machine'
import { z } from 'zod'

const PatchItemSchema = z.object({
  quantity: z.coerce.number().positive().optional(),
  notes: z.string().max(300).optional().or(z.literal('')),
})

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> },
) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ ok: false, error: 'NO_AUTENTICADO' }, { status: 401 })
    if (!['ADMIN', 'MESERO', 'MESERO_PRO'].includes(user.role)) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }
    const { id, itemId } = await params

    const order = await db.order.findUnique({ where: { id } })
    if (!order) return NextResponse.json({ ok: false, error: 'Pedido no encontrado' }, { status: 404 })
    if (user.role !== 'ADMIN' && order.userId !== user.id) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }
    if (['CANCELADO', 'COBRADO', 'ARCHIVADO'].includes(order.status)) {
      return NextResponse.json(
        { ok: false, error: 'No se puede editar items de un pedido cancelado/cobrado' },
        { status: 400 },
      )
    }

    const item = await db.orderItem.findFirst({
      where: { id: itemId, orderId: id },
      include: { product: { select: { id: true, name: true, type: true, unit: true } } },
    })
    if (!item) return NextResponse.json({ ok: false, error: 'Item no encontrado' }, { status: 404 })

    const isDirecto = item.product.type === 'DIRECTO'

    // v1.0-RC1-bloque1-2 (item 16):
    //   - DIRECTO: editable si no está CANCELADO (nace SERVIDO y se puede ajustar).
    //   - FINAL:   editable solo si está PENDIENTE.
    if (item.status === 'CANCELADO') {
      return NextResponse.json({ ok: false, error: 'Item cancelado' }, { status: 400 })
    }
    if (!isDirecto && item.status !== 'PENDIENTE') {
      return NextResponse.json(
        { ok: false, error: `No se puede editar un item en estado ${item.status}` },
        { status: 400 },
      )
    }

    const body = await req.json().catch(() => null)
    if (!body) return NextResponse.json({ ok: false, error: 'Cuerpo inválido' }, { status: 400 })
    const parsed = PatchItemSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: parsed.error.issues[0]?.message || 'Datos inválidos' },
        { status: 400 },
      )
    }
    const d = parsed.data
    const before = { quantity: item.quantity, notes: item.notes }

    const data: any = {}
    if (d.notes !== undefined) data.notes = d.notes || null

    // v1.0-RC1-bloque1-2 (item 16): ajustar diferencia de stock para DIRECTO.
    const config = await db.restaurantConfig.findFirst({ where: { id: 'config-1' } })
    const blockNegative = config?.blockNegativeStock ?? true

    let stockAdjustmentInfo: any = null
    if (d.quantity !== undefined && d.quantity !== item.quantity) {
      data.quantity = d.quantity
      if (isDirecto) {
        const oldQty = item.quantity
        const newQty = d.quantity
        const diff = newQty - oldQty
        if (diff > 0) {
          // Aumentar cantidad: descontar diff más del AreaInventory.
          const res = await decrementDirectoStock(order.areaId, item.productId, diff, {
            blockNegative,
            orderNumber: order.number,
            reference: `${order.id}:item:${item.id}:edit-increase`,
            userId: user.id,
            unit: item.product.unit,
          })
          if (!res.ok) {
            return NextResponse.json(
              { ok: false, error: `Stock insuficiente de "${item.product.name}": ${res.message || 'no se pudo descontar'}` },
              { status: 400 },
            )
          }
          stockAdjustmentInfo = { type: 'increment', diff, result: res }
        } else if (diff < 0) {
          // Disminuir cantidad: devolver abs(diff) al AreaInventory.
          const res = await returnDirectoStock(order.areaId, item.productId, Math.abs(diff), {
            orderNumber: order.number,
            reference: `${order.id}:item:${item.id}:edit-decrease`,
            userId: user.id,
            unit: item.product.unit,
          })
          stockAdjustmentInfo = { type: 'decrement', diff: Math.abs(diff), result: res }
        }
      }
    }

    const updated = await db.orderItem.update({ where: { id: itemId }, data })

    // Recalcular totales del pedido
    await recalcOrderTotals(id)
    await recalculateOrderStatus(id).catch(() => undefined)

    await audit({
      userId: user.id,
      action: 'UPDATE_ORDER_ITEM',
      entity: 'order-item',
      entityId: itemId,
      before,
      after: { ...data, stockAdjustment: stockAdjustmentInfo },
    })

    return NextResponse.json({ ok: true, item: updated, stockAdjustment: stockAdjustmentInfo })
  } catch (e: any) {
    console.error('PATCH /api/mesero/orders/[id]/items/[itemId]', e)
    return NextResponse.json({ ok: false, error: 'Error interno' }, { status: 500 })
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> },
) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ ok: false, error: 'NO_AUTENTICADO' }, { status: 401 })
    if (!['ADMIN', 'MESERO', 'MESERO_PRO'].includes(user.role)) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }
    const { id, itemId } = await params

    const order = await db.order.findUnique({ where: { id } })
    if (!order) return NextResponse.json({ ok: false, error: 'Pedido no encontrado' }, { status: 404 })
    if (user.role !== 'ADMIN' && order.userId !== user.id) {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }
    if (['CANCELADO', 'COBRADO', 'ARCHIVADO'].includes(order.status)) {
      return NextResponse.json(
        { ok: false, error: 'No se puede cancelar items de un pedido cancelado/cobrado' },
        { status: 400 },
      )
    }

    const item = await db.orderItem.findFirst({
      where: { id: itemId, orderId: id },
      include: { product: { select: { id: true, name: true, type: true, unit: true } } },
    })
    if (!item) return NextResponse.json({ ok: false, error: 'Item no encontrado' }, { status: 404 })

    if (item.status === 'CANCELADO') {
      return NextResponse.json({ ok: false, error: 'Item ya cancelado' }, { status: 400 })
    }

    const isDirecto = item.product.type === 'DIRECTO'

    // v1.0-RC1-bloque1-2 (item 17):
    //   - FINAL: solo se puede cancelar si está PENDIENTE.
    //   - DIRECTO: se puede cancelar aunque esté SERVIDO (devuelve stock).
    if (!isDirecto && item.status !== 'PENDIENTE') {
      return NextResponse.json(
        { ok: false, error: `No se puede cancelar un item en estado ${item.status}. Ya está en preparación.` },
        { status: 400 },
      )
    }

    // Soft delete: marcar como CANCELADO + devolver stock si es DIRECTO.
    let stockReturnInfo: any = null
    const updated = await db.$transaction(async (tx) => {
      const upd = await tx.orderItem.update({
        where: { id: itemId },
        data: { status: 'CANCELADO' },
      })

      if (isDirecto) {
        const res = await returnDirectoStock(order.areaId, item.productId, item.quantity, {
          orderNumber: order.number,
          reference: `${order.id}:item:${item.id}:cancel`,
          userId: user.id,
          unit: item.product.unit,
          tx,
        })
        stockReturnInfo = res
      }

      return upd
    })

    // Recalcular totales
    await recalcOrderTotals(id)
    await recalculateOrderStatus(id).catch(() => undefined)

    await audit({
      userId: user.id,
      action: 'CANCEL_ORDER_ITEM',
      entity: 'order-item',
      entityId: itemId,
      before: { status: item.status, quantity: item.quantity, unitPrice: item.unitPrice },
      after: { status: 'CANCELADO', stockReturn: stockReturnInfo },
    })

    return NextResponse.json({ ok: true, item: updated, stockReturn: stockReturnInfo })
  } catch (e: any) {
    console.error('DELETE /api/mesero/orders/[id]/items/[itemId]', e)
    return NextResponse.json({ ok: false, error: 'Error interno' }, { status: 500 })
  }
}

// Helper: recalcular totales del pedido tras añadir/cancelar/editar items
async function recalcOrderTotals(orderId: string) {
  const items = await db.orderItem.findMany({
    where: { orderId, status: { not: 'CANCELADO' } },
  })
  const subtotal = items.reduce((s, it) => s + it.quantity * it.unitPrice, 0)
  const order = await db.order.findUnique({ where: { id: orderId } })
  if (!order) return
  const discountAmount = +(subtotal * (order.discountPct / 100)).toFixed(2)
  const total = +(subtotal - discountAmount).toFixed(2)
  await db.order.update({
    where: { id: orderId },
    data: { subtotal, discountAmount, total },
  })
}
