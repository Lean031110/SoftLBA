// POST /api/admin/printer/test - Comprobar conexión con impresora térmica
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

export async function POST() {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ ok: false, error: 'NO_AUTENTICADO' }, { status: 401 })
    if (user.role !== 'ADMIN') {
      return NextResponse.json({ ok: false, error: 'SIN_PERMISO' }, { status: 403 })
    }

    const config = await db.restaurantConfig.findFirst()
    if (!config || !config.printerEnabled) {
      return NextResponse.json({ ok: false, error: 'Impresora no activada en la configuración' }, { status: 400 })
    }

    if (!config.printerIp || !config.printerPort) {
      return NextResponse.json({ ok: false, error: 'Falta IP o puerto de la impresora' }, { status: 400 })
    }

    // Intentar conexión TCP a la impresora
    try {
      const { net } = await import('net')
      const result = await new Promise<{ ok: boolean; error?: string }>((resolve) => {
        const socket = new net.Socket()
        socket.setTimeout(3000)
        socket.on('connect', () => {
          socket.destroy()
          resolve({ ok: true })
        })
        socket.on('timeout', () => {
          socket.destroy()
          resolve({ ok: false, error: 'Tiempo de espera agotado. La impresora no responde.' })
        })
        socket.on('error', (err) => {
          socket.destroy()
          resolve({ ok: false, error: `Error de conexión: ${err.message}` })
        })
        socket.connect(config.printerPort!, config.printerIp!)
      })

      if (result.ok) {
        return NextResponse.json({
          ok: true,
          message: `Conexión exitosa con impresora ${config.printerName || ''} en ${config.printerIp}:${config.printerPort}`,
        })
      } else {
        return NextResponse.json({ ok: false, error: result.error }, { status: 400 })
      }
    } catch (e: any) {
      return NextResponse.json({ ok: false, error: `Error al conectar: ${e.message}` }, { status: 500 })
    }
  } catch (e: any) {
    console.error('POST /api/admin/printer/test', e)
    return NextResponse.json({ ok: false, error: 'Error interno' }, { status: 500 })
  }
}
